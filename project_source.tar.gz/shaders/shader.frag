#version 450

layout(location = 0) in vec3 fragColor;
layout(location = 1) in vec2 fragUV;
layout(location = 0) out vec4 outColor;

// Hash dla szumu
float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float hash2(vec2 p) {
    return fract(sin(dot(p, vec2(269.5, 183.3))) * 43758.5453123);
}

// Szum value noise
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// FBM - wielowarstwowy szum
float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * noise(p);
        p *= 2.0;
        a *= 0.5;
    }
    return v;
}

void main() {
    // === PIXEL ART 64x64 ===
    // Zaokrąglamy UV do siatki 64x64 pikseli
    vec2 pixelUV = floor(fragUV * 64.0) / 64.0;
    vec2 pixelCoord = floor(fragUV * 64.0); // współrzędne piksela 0-63
    
    // === WZÓR CEGIEŁ (bruk) ===
    // Cegły mają rozmiar 16x8 pikseli, co drugi rząd przesunięty
    float brickW = 16.0;
    float brickH = 8.0;
    
    vec2 brickCoord = vec2(
        floor(pixelCoord.x / brickW),
        floor(pixelCoord.y / brickH)
    );
    
    // Przesunięcie co drugi rząd
    float rowOffset = mod(brickCoord.y, 2.0) * (brickW * 0.5);
    vec2 localBrick = vec2(
        mod(pixelCoord.x + rowOffset, brickW),
        mod(pixelCoord.y, brickH)
    );
    
    // === KOLOR BAZOWY KAMIENIA ===
    // Każdy "kamień" (cegła) ma swój unikalny kolor bazowy
    float stoneSeed = hash(brickCoord);
    float stoneSeed2 = hash2(brickCoord);
    
    // Paleta kolorów kamienia (szaro-brązowa z wariacjami)
    vec3 stoneDark = vec3(0.35, 0.32, 0.30);
    vec3 stoneMid = vec3(0.50, 0.47, 0.44);
    vec3 stoneLight = vec3(0.65, 0.60, 0.55);
    vec3 stoneRed = vec3(0.60, 0.40, 0.35);
    vec3 stoneBrown = vec3(0.55, 0.45, 0.35);
    
    // Wybór koloru bazowego kamienia
    vec3 baseColor;
    if (stoneSeed < 0.4) baseColor = stoneMid;
    else if (stoneSeed < 0.7) baseColor = stoneLight;
    else if (stoneSeed < 0.85) baseColor = stoneDark;
    else if (stoneSeed < 0.93) baseColor = stoneRed;
    else baseColor = stoneBrown;
    
    // === DETAL WEWNĄTRZ KAMIENIA ===
    // Szum wewnątrz każdego kamienia dla faktury
    vec2 stoneDetailUV = pixelCoord * 0.5;
    float stoneNoise = fbm(stoneDetailUV + brickCoord * 100.0);
    
    // Jaśniejsze/ciemniejsze plamy w kamieniu
    baseColor *= (0.75 + 0.35 * stoneNoise);
    
    // Krawędzie kamienia (ciemniejsze) - zaokrąglony kształt
    float edgeDist = min(
        min(localBrick.x, brickW - 1.0 - localBrick.x),
        min(localBrick.y, brickH - 1.0 - localBrick.y)
    );
    float edgeFactor = smoothstep(0.0, 2.0, edgeDist);
    baseColor *= (0.6 + 0.4 * edgeFactor);
    
    // === ZAPRAWA (ciemne linie między cegłami) ===
    float mortarWidth = 1.0;
    float isMortarX = step(localBrick.x, mortarWidth) + step(brickW - mortarWidth, localBrick.x);
    float isMortarY = step(localBrick.y, mortarWidth) + step(brickH - mortarWidth, localBrick.y);
    float isMortar = max(isMortarX, isMortarY);
    
    vec3 mortarColor = vec3(0.20, 0.18, 0.17);
    // Zaprawa też ma szum
    mortarColor *= (0.85 + 0.3 * noise(pixelCoord * 0.3));
    
    baseColor = mix(baseColor, mortarColor, isMortar);
    
    // === MECH ===
    // Mech pojawia się na niektórych cegłach (losowo) i na krawędziach
    float mossChance = hash(brickCoord * 7.3 + 500.0);
    float hasMoss = step(0.72, mossChance); // ~28% cegieł ma mech
    
    // Mech ma własny szum wewnątrz cegły
    float mossNoise = fbm(pixelCoord * 0.4 + brickCoord * 50.0);
    
    // Mech jest bardziej zielony na krawędziach kamienia
    float mossEdgeFactor = 1.0 - edgeFactor;
    float mossAmount = hasMoss * (0.3 + 0.7 * mossEdgeFactor) * mossNoise;
    
    // Kolor mchu (zielony z wariacjami)
    vec3 mossDark = vec3(0.20, 0.35, 0.15);
    vec3 mossLight = vec3(0.40, 0.60, 0.25);
    vec3 mossColor = mix(mossDark, mossLight, mossNoise);
    
    baseColor = mix(baseColor, mossColor, mossAmount * 0.7);
    
    // === KOLOROWE PLAMY (rdza, mineralne) ===
    float spotChance = hash(brickCoord * 3.7 + 1000.0);
    if (spotChance > 0.85) {
        float spotNoise = fbm(pixelCoord * 0.3 + brickCoord * 30.0);
        vec3 rustColor = vec3(0.70, 0.45, 0.30);
        vec3 mineralColor = vec3(0.55, 0.55, 0.65);
        vec3 spotColor = mix(rustColor, mineralColor, hash2(brickCoord));
        baseColor = mix(baseColor, spotColor, spotNoise * 0.4);
    }
    
    // === CIENIE I PODŚWIETLENIA ===
    // Delikatne cieniowanie zależne od pozycji (symulacja światła z góry-lewo)
    float lightFactor = 1.0 - (pixelCoord.y / 64.0) * 0.15;
    baseColor *= lightFactor;
    
    // === ZASTOSUJ KOLOR BAZOWY (cieniowanie ściany z C++) ===
    baseColor *= fragColor;
    
    // === LEKKIE PRZYCIEMNIENIE KRAWĘDZI CAŁEGO BLOKU ===
    float blockEdge = max(
        max(step(0.97, fragUV.x), step(0.97, fragUV.y)),
        max(step(fragUV.x, 0.03), step(fragUV.y, 0.03))
    );
    baseColor *= (1.0 - blockEdge * 0.3);
    
    outColor = vec4(baseColor, 1.0);
}
