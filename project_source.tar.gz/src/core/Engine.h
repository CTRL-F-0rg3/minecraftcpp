#pragma once
#include <vulkan/vulkan.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>
#include "renderer/Renderer.h"
#include "world/World.h"

class Engine {
public:
    Engine(uint32_t width, uint32_t height);
    ~Engine();
    void run();

private:
    Renderer renderer;
    World world;

    // Parametry kamery (noclip)
    glm::vec3 cameraPos;
    glm::vec3 cameraFront;
    glm::vec3 cameraUp;
    float yaw;
    float pitch;
    float movementSpeed;
    float mouseSensitivity;
    bool firstMouse;
    float lastX;
    float lastY;

    void processInput(float deltaTime);
    void updateCameraVectors();
    
    // Statyczny wrapper dla callbacka GLFW
    static void mouseCallbackStatic(GLFWwindow* window, double xpos, double ypos);
    void mouseCallback(double xpos, double ypos);
};
