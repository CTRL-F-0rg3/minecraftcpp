#include "Chunk.h"
#include <cmath>

Chunk::Chunk(int x, int z) : chunkX(x), chunkZ(z) {
    blocks.fill(BlockType::Air);
}

void Chunk::generate() {
    // Proste generowanie terenu - płaski świat z trawą na górze
    for (int x = 0; x < CHUNK_SIZE; x++) {
        for (int z = 0; z < CHUNK_SIZE; z++) {
            int worldX = chunkX * CHUNK_SIZE + x;
            int worldZ = chunkZ * CHUNK_SIZE + z;
            
            // Prosty szum wysokości (można później zastąpić Perlin/Simplex)
            int height = 10 + (std::abs(worldX * 7 + worldZ * 13) % 5);
            
            for (int y = 0; y < height; y++) {
                if (y == height - 1) {
                    blocks[x + y * CHUNK_SIZE * CHUNK_SIZE + z * CHUNK_SIZE] = BlockType::Grass;
                } else if (y > height - 4) {
                    blocks[x + y * CHUNK_SIZE * CHUNK_SIZE + z * CHUNK_SIZE] = BlockType::Dirt;
                } else {
                    blocks[x + y * CHUNK_SIZE * CHUNK_SIZE + z * CHUNK_SIZE] = BlockType::Stone;
                }
            }
        }
    }
}

BlockType Chunk::getBlock(int x, int y, int z) const {
    if (x < 0 || x >= CHUNK_SIZE || y < 0 || y >= CHUNK_HEIGHT || z < 0 || z >= CHUNK_SIZE) {
        return BlockType::Air;
    }
    return blocks[x + y * CHUNK_SIZE * CHUNK_SIZE + z * CHUNK_SIZE];
}

void Chunk::setBlock(int x, int y, int z, BlockType type) {
    if (x >= 0 && x < CHUNK_SIZE && y >= 0 && y < CHUNK_HEIGHT && z >= 0 && z < CHUNK_SIZE) {
        blocks[x + y * CHUNK_SIZE * CHUNK_SIZE + z * CHUNK_SIZE] = type;
    }
}

bool Chunk::isBlockSolid(int x, int y, int z) const {
    return getBlock(x, y, z) != BlockType::Air;
}

void Chunk::addFace(std::vector<Vertex>& vertices, int x, int y, int z, int face) {
    float px = (float)x;
    float py = (float)y;
    float pz = (float)z;
    
    float colors[6][3] = {
        {1.0f, 1.0f, 1.0f}, {1.0f, 1.0f, 1.0f}, {1.0f, 1.0f, 1.0f},
        {1.0f, 1.0f, 1.0f}, {1.0f, 1.0f, 1.0f}, {1.0f, 1.0f, 1.0f}
    };
    float* c = colors[face];
    
    auto addV = [&](float x, float y, float z, float u, float v) {
        vertices.push_back({{px+x, py+y, pz+z}, {c[0], c[1], c[2]}, {u, v}});
    };

    switch(face) {
        case 0:
            addV(1, 0, 0, 0, 0); addV(1, 1, 0, 0, 1); addV(1, 1, 1, 1, 1);
            addV(1, 0, 0, 0, 0); addV(1, 1, 1, 1, 1); addV(1, 0, 1, 1, 0); break;
        case 1:
            addV(0, 0, 1, 0, 0); addV(0, 1, 1, 0, 1); addV(0, 1, 0, 1, 1);
            addV(0, 0, 1, 0, 0); addV(0, 1, 0, 1, 1); addV(0, 0, 0, 1, 0); break;
        case 2:
            addV(0, 1, 0, 0, 0); addV(1, 1, 1, 1, 1); addV(1, 1, 0, 1, 0);
            addV(0, 1, 0, 0, 0); addV(0, 1, 1, 0, 1); addV(1, 1, 1, 1, 1); break;
        case 3:
            addV(0, 0, 1, 0, 0); addV(1, 0, 0, 1, 1); addV(1, 0, 1, 1, 0);
            addV(0, 0, 1, 0, 0); addV(0, 0, 0, 0, 1); addV(1, 0, 0, 1, 1); break;
        case 4:
            addV(1, 0, 1, 0, 0); addV(1, 1, 1, 0, 1); addV(0, 1, 1, 1, 1);
            addV(1, 0, 1, 0, 0); addV(0, 1, 1, 1, 1); addV(0, 0, 1, 1, 0); break;
        case 5:
            addV(0, 0, 0, 0, 0); addV(0, 1, 0, 0, 1); addV(1, 1, 0, 1, 1);
            addV(0, 0, 0, 0, 0); addV(1, 1, 0, 1, 1); addV(1, 0, 0, 1, 0); break;
    }
}

std::vector<Vertex> Chunk::generateMesh() {
    std::vector<Vertex> vertices;
    
    for (int y = 0; y < CHUNK_HEIGHT; y++) {
        for (int z = 0; z < CHUNK_SIZE; z++) {
            for (int x = 0; x < CHUNK_SIZE; x++) {
                BlockType block = getBlock(x, y, z);
                if (block == BlockType::Air) continue;
                
                if (!isBlockSolid(x+1, y, z)) addFace(vertices, x, y, z, 0);
                if (!isBlockSolid(x-1, y, z)) addFace(vertices, x, y, z, 1);
                if (!isBlockSolid(x, y+1, z)) addFace(vertices, x, y, z, 2);
                if (!isBlockSolid(x, y-1, z)) addFace(vertices, x, y, z, 3);
                if (!isBlockSolid(x, y, z+1)) addFace(vertices, x, y, z, 4);
                if (!isBlockSolid(x, y, z-1)) addFace(vertices, x, y, z, 5);
            }
        }
    }
    
    return vertices;
}

